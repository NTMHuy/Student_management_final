package com.example.student_management_api.user;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmailIgnoreCase(String email);

    Optional<User> findByTeacherId(Long teacherId);

    List<User> findAllByOrderByIdAsc();
}
